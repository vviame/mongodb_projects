from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from pymongo import MongoClient, ReadPreference, WriteConcern
from pymongo.errors import OperationFailure, PyMongoError

SET_NAME = "rs0"
BOOTSTRAP = ["mongo1:27017", "mongo2:27017", "mongo3:27017"]
TIMEOUT_MS = 1500

app = FastAPI()

# One long-lived client that follows the replica set (finds the current primary by itself).
rs_client = MongoClient(
    "mongodb://" + ",".join(BOOTSTRAP) + f"/?replicaSet={SET_NAME}",
    serverSelectionTimeoutMS=3000,
)
orders = rs_client.shop.get_collection("orders", write_concern=WriteConcern(w="majority", wtimeout=3000))


def direct(host: str) -> MongoClient:
    """Connect to ONE specific member, without replica-set discovery."""
    return MongoClient(
        f"mongodb://{host}/?directConnection=true",
        serverSelectionTimeoutMS=TIMEOUT_MS,
        connectTimeoutMS=TIMEOUT_MS,
    )


def ask_member(host: str):
    """Return replSetGetStatus from one member, or an error marker."""
    client = direct(host)
    try:
        return {"host": host, "status": client.admin.command("replSetGetStatus")}
    except OperationFailure as e:
        if e.code == 94:  # NotYetInitialized
            return {"host": host, "not_initiated": True}
        return {"host": host, "error": str(e)}
    except PyMongoError as e:
        return {"host": host, "error": str(e)}
    finally:
        client.close()


def cluster_status():
    with ThreadPoolExecutor(max_workers=len(BOOTSTRAP)) as pool:
        answers = list(pool.map(ask_member, BOOTSTRAP))

    statuses = [a["status"] for a in answers if "status" in a]
    if not statuses:
        if any(a.get("not_initiated") for a in answers):
            return {"reachable": True, "initiated": False}
        return {"reachable": False, "initiated": False}

    # Prefer the view of the primary; fall back to any member that answered.
    status = next((s for s in statuses if s.get("myState") == 1), statuses[0])
    members = status["members"]
    newest = max((m["optimeDate"] for m in members if m.get("optimeDate")), default=None)

    out = []
    for m in members:
        lag = None
        if newest and m.get("optimeDate"):
            lag = (newest - m["optimeDate"]).total_seconds()
        out.append({
            "name": m["name"],
            "state": m["state"],
            "stateStr": m["stateStr"],
            "health": m["health"],
            "uptime": m.get("uptime"),
            "lag": lag,
        })
    primary = next((m["name"] for m in members if m["state"] == 1), None)
    return {
        "reachable": True,
        "initiated": True,
        "set": status["set"],
        "term": status.get("term"),
        "primary": primary,
        "members": out,
    }


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/status")
def status():
    return cluster_status()


@app.post("/init")
def init_replica_set():
    client = direct(BOOTSTRAP[0])
    config = {
        "_id": SET_NAME,
        "members": [{"_id": i, "host": h} for i, h in enumerate(BOOTSTRAP)],
    }
    try:
        client.admin.command("replSetInitiate", config)
    except PyMongoError as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        client.close()
    return {"ok": True}


class OrderIn(BaseModel):
    product: str = Field(min_length=1, max_length=80)
    quantity: int = Field(ge=1, le=10000)


@app.post("/orders")
def add_order(order: OrderIn):
    try:
        res = orders.insert_one({
            "product": order.product.strip(),
            "quantity": order.quantity,
            "created": datetime.utcnow(),
        })
    except PyMongoError:
        raise HTTPException(
            status_code=503,
            detail="Write refused: no primary is available (a majority of members is needed).",
        )
    return {"inserted": str(res.inserted_id)}


@app.delete("/orders")
def clear_orders():
    try:
        orders.delete_many({})
    except PyMongoError:
        raise HTTPException(status_code=503, detail="Write refused: no primary is available.")
    return {"ok": True}


def read_member(member: dict):
    host = member["name"]
    client = direct(host)
    try:
        coll = client.shop.get_collection("orders", read_preference=ReadPreference.SECONDARY_PREFERRED)
        recent = [
            {"id": str(d["_id"]), "product": d.get("product"), "quantity": d.get("quantity"),
             "created": d["created"].isoformat() + "Z" if d.get("created") else None}
            for d in coll.find().sort("_id", -1).limit(5)
        ]
        return {"name": host, "stateStr": member["stateStr"], "count": coll.count_documents({}), "recent": recent}
    except PyMongoError:
        return {"name": host, "stateStr": member["stateStr"], "error": "unreachable"}
    finally:
        client.close()


@app.get("/replication")
def replication():
    st = cluster_status()
    if not st.get("initiated"):
        return {"members": []}
    with ThreadPoolExecutor(max_workers=len(st["members"])) as pool:
        return {"members": list(pool.map(read_member, st["members"]))}
